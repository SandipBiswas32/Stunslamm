package com.sandip.shieldswap.mixin.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.lang.reflect.Field;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Decompiled + cleaned from modernfix-1_0_0.jar (ClientPlayerInteractionManagerMixin).
 *
 * When you hit a target that is blocking with a shield:
 *  - airborne, holding a sword, axe + mace      -> swap to axe, hit, then mace hit 50ms later, swap back
 *  - airborne, holding an axe, mace in hotbar   -> normal axe hit, then mace hit 50ms later, swap back
 */
@Mixin(MultiPlayerGameMode.class)
public abstract class MultiPlayerGameModeMixin {

    @Shadow @Final private Minecraft minecraft;

    @Shadow public abstract void ensureHasSentCarriedItem();

    @Unique private boolean shieldswap$processing = false;

    @Unique private static final ScheduledExecutorService shieldswap$scheduler =
            Executors.newSingleThreadScheduledExecutor();

    @Unique private static Field shieldswap$selectedField;

    static {
        // field_7545 = intermediary, selected = mojmap, f_36024_ = old srg
        for (String name : new String[]{"field_7545", "selected", "f_36024_"}) {
            try {
                shieldswap$selectedField = Inventory.class.getDeclaredField(name);
                shieldswap$selectedField.setAccessible(true);
                break;
            } catch (Exception ignored) {
            }
        }
        if (shieldswap$selectedField == null) {
            throw new RuntimeException("Could not find Inventory.selected field!");
        }
    }

    @Unique
    private void shieldswap$setSelected(Inventory inventory, int slot) {
        try {
            shieldswap$selectedField.setInt(inventory, slot);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Inject(method = "attack", at = @At("HEAD"), cancellable = true)
    private void shieldswap$onAttack(Player player, Entity target, CallbackInfo ci) {
        if (shieldswap$processing) return;
        if (!(target instanceof LivingEntity living)) return;
        if (!shieldswap$isBlocking(living)) return;

        LocalPlayer self = this.minecraft.player;
        if (self == null || player != self) return;

        ItemStack held = self.getMainHandItem();
        boolean holdingSword = shieldswap$isSword(held);
        boolean holdingAxe = held.getItem() instanceof AxeItem;
        boolean airborne = !self.onGround();

        int axeSlot = shieldswap$findItem(self, true);
        int maceSlot = shieldswap$findItem(self, false);
        int originalSlot = self.getInventory().selected;

        if (airborne && holdingSword && axeSlot != -1 && maceSlot != -1) {
            ci.cancel();
            shieldswap$swapAndAttack(self, axeSlot, originalSlot, maceSlot, target);
        } else if (airborne && holdingAxe && maceSlot != -1) {
            shieldswap$scheduleMaceFollowup(self, maceSlot, originalSlot, target);
        }
    }

    @Unique
    private boolean shieldswap$isSword(ItemStack stack) {
        return stack.is(Items.WOODEN_SWORD)
                || stack.is(Items.STONE_SWORD)
                || stack.is(Items.IRON_SWORD)
                || stack.is(Items.GOLDEN_SWORD)
                || stack.is(Items.DIAMOND_SWORD)
                || stack.is(Items.NETHERITE_SWORD);
    }

    @Unique
    private boolean shieldswap$isBlocking(LivingEntity entity) {
        return entity.isUsingItem() && entity.getUseItem().is(Items.SHIELD);
    }

    /** hotbar search: axe if wantAxe, otherwise mace. -1 if none. */
    @Unique
    private int shieldswap$findItem(LocalPlayer player, boolean wantAxe) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getItem(i);
            if (wantAxe && stack.getItem() instanceof AxeItem) return i;
            if (!wantAxe && stack.is(Items.MACE)) return i;
        }
        return -1;
    }

    @Unique
    private void shieldswap$swapAndAttack(LocalPlayer player, int axeSlot, int originalSlot, int maceSlot, Entity target) {
        shieldswap$processing = true;
        shieldswap$setSelected(player.getInventory(), axeSlot);
        this.ensureHasSentCarriedItem();
        shieldswap$processing = false;
        ((MultiPlayerGameMode) (Object) this).attack(player, target);
        shieldswap$processing = true;
        player.swing(InteractionHand.MAIN_HAND);

        if (maceSlot != -1) {
            shieldswap$scheduleMaceStrike(target, maceSlot, originalSlot);
        } else {
            shieldswap$scheduleRestore(originalSlot);
        }
    }

    @Unique
    private void shieldswap$scheduleMaceFollowup(LocalPlayer player, int maceSlot, int originalSlot, Entity target) {
        shieldswap$processing = true;
        shieldswap$scheduleMaceStrike(target, maceSlot, originalSlot);
    }

    /** 50ms later (on the client thread): swap to mace, attack, then schedule restore of restoreSlot. */
    @Unique
    private void shieldswap$scheduleMaceStrike(Entity target, int maceSlot, int restoreSlot) {
        shieldswap$scheduler.schedule(() -> this.minecraft.execute(() -> {
            if (this.minecraft.player != null && target != null) {
                shieldswap$setSelected(this.minecraft.player.getInventory(), maceSlot);
                this.ensureHasSentCarriedItem();
                shieldswap$processing = false;
                ((MultiPlayerGameMode) (Object) this).attack(this.minecraft.player, target);
                shieldswap$processing = true;
                this.minecraft.player.swing(InteractionHand.MAIN_HAND);
                shieldswap$scheduleRestore(restoreSlot);
            }
        }), 50L, TimeUnit.MILLISECONDS);
    }

    /** 50ms later (on the client thread): put the hotbar slot back and re-enable the hook. */
    @Unique
    private void shieldswap$scheduleRestore(int slot) {
        shieldswap$scheduler.schedule(() -> this.minecraft.execute(() -> {
            if (this.minecraft.player != null) {
                shieldswap$setSelected(this.minecraft.player.getInventory(), slot);
                shieldswap$processing = false;
            }
        }), 50L, TimeUnit.MILLISECONDS);
    }
}

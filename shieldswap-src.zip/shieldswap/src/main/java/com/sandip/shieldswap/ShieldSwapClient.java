package com.sandip.shieldswap;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ShieldSwapClient implements ClientModInitializer {
    public static final String MOD_ID = "shieldswap";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        LOGGER.info("ShieldSwap loaded");
    }
}

# ShieldSwap (decompiled from modernfix-1_0_0.jar)
Fabric 1.21.11, Mojang mappings, Java 21.
Build: GitHub Actions (.github/workflows/build.yml) -> artifact `shieldswap`, ya local `gradle build`.
